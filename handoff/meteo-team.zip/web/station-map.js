import {loadRaster, loadReserveObjects, rasterOffsets, reserveDetailRaster, reserveRaster, russiaRaster} from './station-map-raster.js';

const reserve = {latitude: 56.464310, longitude: 32.970290};
const russiaExtent = [{latitude: 41, longitude: 19}, {latitude: 82.3, longitude: -169}];
const initialScale = 410;
const maxScale = 110000;
const markerWidth = 50;
const markerHeight = 40;
const markerOffsets = [[-56, -48], [56, -48], [0, 58], [-56, 48], [56, 48], [0, -58], [-68, 0], [68, 0]];
const degrees = Math.PI / 180;
const wrapLongitude = longitude => ((longitude + 180) % 360 + 360) % 360 - 180;

function longitudeFrame(points) {
  const longitudes = points.map(point => wrapLongitude(point.longitude)).sort((a, b) => a - b);
  let start = longitudes[0];
  let largestGap = 0;
  for (const [index, longitude] of longitudes.entries()) {
    const next = longitudes[index + 1] ?? longitudes[0] + 360;
    if (next - longitude > largestGap) {
      largestGap = next - longitude;
      start = next;
    }
  }
  const span = 360 - largestGap;
  return {longitude: wrapLongitude(start + span / 2), span};
}

let mapId = 0;
let passportId = 0;
const coordinateFormat = new Intl.NumberFormat('ru', {maximumFractionDigits: 5});
const terrains = {
  clearing: ['Поляна', '#5e6b2d'],
  field: ['Поле', '#8a5628'],
  forest: ['Лес', '#256248'],
  wetland: ['Болото', '#2d6971'],
  settlement: ['Населённый пункт', '#6d5178'],
  other: ['Другая местность', '#494f78'],
  unknown: ['Тип местности не указан', '#58675f'],
};
const icons = {
  close: '<path d="m6 6 12 12M18 6 6 18"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  locate: '<circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/><path d="M12 2v4m0 12v4M2 12h4m12 0h4"/>',
  fit: '<path d="M9 4H4v5m11-5h5v5M4 15v5h5m11-5v5h-5"/>',
  pin: '<path d="M19 10c0 5-7 10-7 10s-7-5-7-10a7 7 0 1 1 14 0Z"/><circle cx="12" cy="10" r="2"/>',
  select: '<path d="M8 4H4v4m6-4h4m2 0h4v4m0 2v4m0 2v4h-4m-2 0h-4m-2 0H4v-4m0-2v-4"/>',
  pan: '<path d="M12 4v16M4 12h16M9 7l3-3 3 3M9 17l3 3 3-3M7 9l-3 3 3 3m10-6 3 3-3 3"/>',
  passport: '<path d="M5 3h10l4 4v14H5zM14 3v5h5M8 12h8M8 16h6"/>',
};

function icon(name) {
  return `<svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round">${icons[name]}</svg>`;
}

function location(station) {
  const {latitude, longitude} = station;
  if (Number.isFinite(latitude) && Math.abs(latitude) <= 90 &&
      Number.isFinite(longitude) && Math.abs(longitude) <= 180) return {latitude, longitude};
  return station.location_precision === 'area' ? reserve : null;
}

function coordinates({latitude, longitude}) {
  const lat = `${coordinateFormat.format(Math.abs(latitude))}° ${latitude < 0 ? 'ю.' : 'с.'} ш.`;
  const lon = `${coordinateFormat.format(Math.abs(longitude))}° ${longitude < 0 ? 'з.' : 'в.'} д.`;
  return `${lat}, ${lon}`;
}

function terrainType(station) {
  return Object.hasOwn(terrains, station.terrain) ? station.terrain : 'unknown';
}

function stationLocation(station, point) {
  if (station.location_precision === 'area') {
    return station.location_label ? `Район заповедника · ${station.location_label}` : 'Район заповедника';
  }
  return point ? coordinates(point) : 'Координаты отсутствуют';
}

function stationPassport(station, locationLabel, id) {
  const panel = document.createElement('div');
  panel.id = id;
  panel.className = 'station-row-passport';
  panel.hidden = true;
  panel.innerHTML = `<dl><dt>Тип местности</dt><dd data-terrain></dd><dt>Местоположение</dt><dd data-location></dd></dl>
    <p>Доступные показатели</p><ul></ul>`;
  panel.querySelector('[data-terrain]').textContent = terrains[terrainType(station)][0];
  panel.querySelector('[data-location]').textContent = locationLabel;
  if (station.location_precision === 'area' && station.location_reference) {
    const title = document.createElement('dt');
    title.textContent = 'Ориентир';
    const reference = document.createElement('dd');
    reference.textContent = station.location_reference;
    panel.querySelector('dl').append(title, reference);
  }
  const params = panel.querySelector('ul');
  for (const {label, unit} of station.params || []) {
    const parameter = document.createElement('li');
    parameter.textContent = unit ? `${label} · ${unit}` : label;
    params.append(parameter);
  }
  if (!params.childElementCount) {
    const empty = document.createElement('li');
    empty.textContent = 'Показатели не указаны.';
    params.append(empty);
  }
  return panel;
}

function createMap(viewport, onPick, onSelect) {
  const canvas = viewport.querySelector('canvas');
  const overlay = viewport.querySelector('.station-map-markers');
  const displacedNote = viewport.parentElement.querySelector('[data-displaced-note]');
  const denseNote = viewport.parentElement.querySelector('[data-dense-note]');
  const areaNote = viewport.parentElement.querySelector('[data-area-note]');
  const imageryNote = viewport.parentElement.querySelector('[data-reserve-credit]');
  const objectsNote = viewport.parentElement.querySelector('[data-reserve-objects-credit]');
  const scaleLine = viewport.querySelector('.station-map-scale');
  const frame = viewport.querySelector('.station-map-frame');
  const modes = [...viewport.querySelectorAll('[data-map-mode]')];
  const controls = viewport.querySelectorAll('.station-map-modes, .station-map-tools, .station-map-jumps');
  const context = canvas.getContext('2d');
  viewport.style.setProperty('--station-marker-width', `${markerWidth}px`);
  viewport.style.setProperty('--station-marker-height', `${markerHeight}px`);
  let geography;
  let russiaGeography;
  let reserveObjects;
  let requestedObjects = false;
  let requestedGeography = false;
  let requestedRussia = false;
  const rasterImages = new Map();
  const bound = (value, low, high) => Math.min(Math.max(value, low), high);
  const worldScale = () => Math.min(viewport.clientWidth / 370, viewport.clientHeight / 190);
  const cosine = latitude => Math.max(0.25, Math.cos(latitude * degrees));
  let center = reserve;
  let scale = initialScale;
  let atReserve = true;
  let hasFrame = false;
  let width = 0;
  let height = 0;
  let pendingFrame;
  let markers = [];
  let displayedMarkers = [];
  let draft = null;
  let fittedPoints = null;
  let mode = 'select';
  let picking = false;
  let pointer = null;
  const isReserve = ({latitude, longitude}) => Math.abs(latitude - reserve.latitude) < 0.003 &&
    Math.abs(longitude - reserve.longitude) < 0.003;

  function reserveScale() {
    const [left, bottom, right, top] = reserveRaster.bounds;
    const longitudeMargin = Math.min(reserve.longitude - left, right - reserve.longitude);
    const latitudeMargin = Math.min(reserve.latitude - bottom, top - reserve.latitude);
    return Math.max(initialScale, width / (1.91 * longitudeMargin * cosine(reserve.latitude)),
      height / (1.91 * latitudeMargin));
  }

  const projectUnwrapped = (longitude, latitude) => [
    width / 2 + (longitude - center.longitude) * scale * cosine(center.latitude),
    height / 2 - (latitude - center.latitude) * scale,
  ];
  const project = (longitude, latitude) =>
    projectUnwrapped(center.longitude + wrapLongitude(longitude - center.longitude), latitude);
  function unproject(x, y, wrap = true) {
    const longitude = center.longitude + (x - width / 2) / (scale * cosine(center.latitude));
    return {longitude: wrap ? wrapLongitude(longitude) : longitude,
      latitude: bound(center.latitude - (y - height / 2) / scale, -90, 90)};
  }

  function setCenter(latitude, longitude) {
    center = {latitude: bound(latitude, -90, 90), longitude: wrapLongitude(longitude)};
  }

  function trace(shapes, close = false) {
    context.beginPath();
    for (const [left, bottom, right, top, points, minScale = 0] of shapes) {
      if (scale < minScale || top < south || bottom > north) continue;
      const first = Math.ceil((west - right) / 360);
      const last = Math.floor((east - left) / 360);
      for (let copy = first; copy <= last; copy++) {
        const offset = copy * 360;
        context.moveTo(...projectUnwrapped(points[0] + offset, points[1]));
        for (let i = 2; i < points.length; i += 2) context.lineTo(...projectUnwrapped(points[i] + offset, points[i + 1]));
        if (close) context.closePath();
      }
    }
  }

  function drawRussiaLand(data, landColor) {
    context.save();
    trace(data.russiaLand, true);
    context.fillStyle = landColor;
    context.fill('evenodd');
    trace(data.russiaCoastlines);
    context.strokeStyle = '#aabfb4';
    context.lineWidth = 0.75;
    context.stroke();
    context.restore();
  }

  function drawRaster(layer, opacity = 1) {
    const offsets = rasterOffsets(layer.bounds, {west, south, east, north});
    if (!offsets.length) return false;
    if (!rasterImages.has(layer)) {
      rasterImages.set(layer, null);
      loadRaster(layer).then(image => {
        rasterImages.set(layer, image);
        if (viewport.isConnected) redraw();
      });
    }
    const image = rasterImages.get(layer);
    if (!image) return false;
    const [left, bottom, right, top] = layer.bounds;
    context.save();
    context.globalAlpha = opacity;
    let rendered = false;
    for (const offset of offsets) {
      const [x, y] = projectUnwrapped(left + offset, top);
      const [rightX, bottomY] = projectUnwrapped(right + offset, bottom);
      const visibleX = Math.max(0, x);
      const visibleY = Math.max(0, y);
      const visibleWidth = Math.min(width, rightX) - visibleX;
      const visibleHeight = Math.min(height, bottomY) - visibleY;
      if (visibleWidth <= 0 || visibleHeight <= 0) continue;
      const sourceX = image.width / (rightX - x);
      const sourceY = image.height / (bottomY - y);
      context.drawImage(image, (visibleX - x) * sourceX, (visibleY - y) * sourceY,
        visibleWidth * sourceX, visibleHeight * sourceY, visibleX, visibleY, visibleWidth, visibleHeight);
      rendered = true;
    }
    context.restore();
    return rendered;
  }

  function markerBounds(x, y) {
    return [x - markerWidth / 2 - 5, y - markerHeight / 2 - 5, x + markerWidth / 2 + 5, y + markerHeight / 2 + 5];
  }

  function overlaps(a, b) {
    return a[0] < b[2] && a[2] > b[0] && a[1] < b[3] && a[3] > b[1];
  }

  function freeMarkerPosition(x, y, occupied) {
    const bounds = markerBounds(x, y);
    return bounds[0] >= 4 && bounds[1] >= 4 && bounds[2] <= width - 4 && bounds[3] <= height - 4 &&
      !occupied.some(other => overlaps(bounds, other));
  }

  function displacedPosition(anchorX, anchorY, occupied) {
    const rings = Math.ceil(Math.max(width, height) / 48);
    for (let ring = 1; ring <= rings; ring++) {
      for (const [dx, dy] of markerOffsets) {
        const x = anchorX + dx * ring;
        const y = anchorY + dy * ring;
        if (freeMarkerPosition(x, y, occupied)) return {x, y};
      }
    }
    for (let y = 30; y < height; y += markerHeight + 12) {
      for (let x = 34; x < width; x += markerWidth + 12) {
        if (freeMarkerPosition(x, y, occupied)) return {x, y};
      }
    }
    return null;
  }

  function positionMarkers(occupied) {
    const visible = [];
    for (const marker of markers) {
      const [anchorX, anchorY] = project(marker.point.longitude, marker.point.latitude);
      if (anchorX < 0 || anchorX > width || anchorY < 0 || anchorY > height) {
        marker.element.hidden = true;
        continue;
      }
      visible.push({marker, anchorX, anchorY, bounds: markerBounds(anchorX, anchorY)});
    }
    displayedMarkers = [];
    const displaced = [];
    function place(item, x, y) {
      const {marker, anchorX, anchorY} = item;
      const moved = x !== anchorX || y !== anchorY;
      marker.element.style.left = `${x}px`;
      marker.element.style.top = `${y}px`;
      marker.element.dataset.anchorX = anchorX;
      marker.element.dataset.anchorY = anchorY;
      marker.element.toggleAttribute('data-displaced', moved);
      marker.element.hidden = false;
      occupied.push(markerBounds(x, y));
      displayedMarkers.push({marker, anchorX, anchorY, x, y, moved});
    }
    for (const item of visible) {
      const {anchorX, anchorY, bounds} = item;
      if (freeMarkerPosition(anchorX, anchorY, occupied) &&
          !visible.some(other => other !== item && overlaps(bounds, other.bounds))) {
        place(item, anchorX, anchorY);
      } else {
        displaced.push(item);
      }
    }
    // Keep the registration coordinates at the origin of each leader. Only button positions move.
    const anchors = displaced.map(({anchorX, anchorY}) => [anchorX - 4, anchorY - 4, anchorX + 4, anchorY + 4]);
    const reserved = [...occupied, ...anchors];
    for (const item of displaced) {
      const next = displacedPosition(item.anchorX, item.anchorY, reserved);
      if (!next) {
        item.marker.element.hidden = true;
        continue;
      }
      place(item, next.x, next.y);
      reserved.push(markerBounds(next.x, next.y));
    }
    occupied.push(...anchors);
    areaNote.hidden = !displayedMarkers.some(({marker}) => marker.area);
    displacedNote.hidden = !displayedMarkers.some(position => position.moved);
    denseNote.hidden = displayedMarkers.length === visible.length;
  }

  function drawMarkerAnchors() {
    const displaced = displayedMarkers.filter(position => position.moved);
    if (!displaced.length) return;
    context.save();
    context.lineCap = 'round';
    for (const {marker, anchorX, anchorY, x, y} of displaced) {
      context.beginPath();
      context.moveTo(anchorX, anchorY);
      context.lineTo(x, y);
      context.lineWidth = 3.5;
      context.strokeStyle = '#fffdf1';
      context.stroke();
      context.lineWidth = 1.65;
      context.strokeStyle = marker.color;
      context.stroke();
    }
    // Draw the geographic origins over the leaders so a shared origin remains visible.
    for (const {anchorX, anchorY} of displaced) {
      context.beginPath();
      context.arc(anchorX, anchorY, 3.7, 0, Math.PI * 2);
      context.fillStyle = '#172c23';
      context.fill();
      context.lineWidth = 1.6;
      context.strokeStyle = '#fffdf1';
      context.stroke();
    }
    context.restore();
  }

  let west, east, south, north;
  function draw() {
    pendingFrame = null;
    width = viewport.clientWidth;
    height = viewport.clientHeight;
    if (!width || !height) return;
    if (atReserve) scale = reserveScale();
    ({longitude: west, latitude: north} = unproject(0, 0, false));
    ({longitude: east, latitude: south} = unproject(width, height, false));
    const bounds = {west, south, east, north};
    const reserveVisible = scale >= 135 && rasterOffsets(reserveRaster.bounds, bounds).length > 0;
    const detailOffsets = scale >= reserveDetailRaster.minScale ? rasterOffsets(reserveDetailRaster.bounds, bounds) : [];
    const russiaVisible = rasterOffsets(russiaRaster.bounds, bounds).length > 0;
    if (!requestedGeography && reserveVisible) {
      requestedGeography = true;
      import('./station-map-data.js').then(data => {
        geography = data;
        if (viewport.isConnected) redraw();
      }).catch(() => {
        const source = viewport.parentElement?.querySelector('.station-map-source span');
        if (source) source.textContent = 'Географическая основа недоступна. Станции показаны по координатам.';
      });
    }
    const [localWest, localSouth, localEast, localNorth] = reserveRaster.bounds;
    const closeToReserve = reserveVisible && center.longitude >= localWest && center.longitude <= localEast &&
      center.latitude >= localSouth && center.latitude <= localNorth;
    if (!requestedRussia && russiaVisible && !closeToReserve) {
      requestedRussia = true;
      import('./russia-map-data.js').then(data => {
        russiaGeography = data;
        if (viewport.isConnected) redraw();
      }).catch(() => {});
    }
    if (detailOffsets.length && !requestedObjects) {
      requestedObjects = true;
      loadReserveObjects().then(data => {
        reserveObjects = data;
        if (viewport.isConnected) redraw();
      });
    }
    const {land = [], lakes = [], places = [], rivers = [], roads = []} = (reserveVisible ? geography : null) || {};
    const detail = russiaVisible && !closeToReserve ? russiaGeography : null;
    const objects = detailOffsets.length ? reserveObjects : null;
    const water = '#d7e8ea';
    const background = '#e3ebe7';
    const landColor = '#edf0de';
    const pixelRatio = Math.min(2, window.devicePixelRatio || 1);
    const pixelWidth = Math.round(width * pixelRatio);
    const pixelHeight = Math.round(height * pixelRatio);
    if (canvas.width !== pixelWidth) canvas.width = pixelWidth;
    if (canvas.height !== pixelHeight) canvas.height = pixelHeight;
    context.setTransform(pixelWidth / width, 0, 0, pixelHeight / height, 0, 0);
    context.fillStyle = background;
    context.fillRect(0, 0, width, height);
    trace(land, true);
    context.fillStyle = landColor;
    context.fill('evenodd');
    if (detail?.russiaLand.length) drawRussiaLand(detail, landColor);
    const national = russiaVisible && !closeToReserve && drawRaster(russiaRaster);
    const localOverview = reserveVisible && drawRaster(reserveRaster, .88);
    const localDetail = detailOffsets.length > 0 && drawRaster(reserveDetailRaster, .88);
    const local = localOverview || localDetail;
    viewport.dataset.mapRaster = local ? 'reserve' : national ? 'russia' : 'vector';
    viewport.dataset.mapDetail = localDetail ? 'sentinel-2' : '';
    viewport.dataset.mapObjects = objects ? 'osm' : '';
    imageryNote.hidden = !local;
    objectsNote.hidden = !objects;

    const cell = [0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2, 5, 10, 20, 45, 90]
      .find(value => value * scale * cosine(center.latitude) >= 48) || 90;
    context.beginPath();
    for (let lon = Math.ceil(west / cell) * cell; lon <= east; lon += cell) {
      context.moveTo(...projectUnwrapped(lon, north));
      context.lineTo(...projectUnwrapped(lon, south));
    }
    for (let lat = Math.ceil(south / cell) * cell; lat <= north; lat += cell) {
      context.moveTo(...projectUnwrapped(west, lat));
      context.lineTo(...projectUnwrapped(east, lat));
    }
    context.strokeStyle = local ? '#f5f9eb21' : '#5d7a661f';
    context.lineWidth = 0.75;
    context.stroke();

    context.save();
    if (objects) {
      context.beginPath();
      context.rect(0, 0, width, height);
      const [left, bottom, right, top] = reserveDetailRaster.bounds;
      for (const offset of detailOffsets) {
        const [x, y] = projectUnwrapped(left + offset, top);
        const [x2, y2] = projectUnwrapped(right + offset, bottom);
        context.rect(x, y, x2 - x, y2 - y);
      }
      context.clip('evenodd');
    }
    if (detail || scale >= 10) {
      trace(detail ? detail.russiaRivers : rivers);
      context.strokeStyle = '#94bfc8';
      context.lineWidth = 1.1;
      context.stroke();
      trace(detail ? detail.russiaLakes : lakes, true);
      context.fillStyle = '#c3dfe2';
      context.fill('evenodd');
      context.strokeStyle = '#9fbfc1';
      context.lineWidth = 0.7;
      context.stroke();
    }
    if (detail || scale >= 75) {
      trace(detail ? detail.russiaRoads : roads);
      context.strokeStyle = '#faf8ef';
      context.lineWidth = 3;
      context.stroke();
      context.strokeStyle = '#c5ad88';
      context.lineWidth = 1.1;
      context.stroke();
    }
    context.restore();
    if (objects) {
      context.save();
      context.lineCap = 'round';
      context.lineJoin = 'round';
      trace(objects.waterways);
      context.strokeStyle = '#88c3cf';
      context.lineWidth = 1.25;
      context.stroke();

      trace(objects.buildings, true);
      context.fillStyle = '#ead8b8';
      context.fill('evenodd');
      context.strokeStyle = '#6f6049';
      context.lineWidth = 1;
      context.stroke();

      trace(objects.paths);
      context.setLineDash([3, 3]);
      context.strokeStyle = '#f7eabe';
      context.lineWidth = 1.3;
      context.stroke();
      context.setLineDash([]);

      trace(objects.roads);
      context.strokeStyle = '#705f4a';
      context.lineWidth = 3.8;
      context.stroke();
      context.strokeStyle = '#f4e6bd';
      context.lineWidth = 2.3;
      context.stroke();
      context.restore();
    }
    if (detail) {
      trace(detail.russiaBoundaries);
      context.strokeStyle = '#8a9a8880';
      context.lineWidth = 0.7;
      context.stroke();
      trace(detail.russiaBorders);
      context.strokeStyle = '#677e69';
      context.lineWidth = 1;
      context.stroke();
    }

    const occupied = Array.from(controls, control => [control.offsetLeft - 6, control.offsetTop - 6,
      control.offsetLeft + control.offsetWidth + 6, control.offsetTop + control.offsetHeight + 6]);
    const font = getComputedStyle(viewport).fontFamily;
    context.textBaseline = 'middle';
    positionMarkers(occupied);
    drawMarkerAnchors();

    const overviewLabels = detail ? [...detail.russiaPlaces, ...detail.russiaWaterLabels, ...places] : places;
    const geographicLabels = objects ? [...objects.labels, ...overviewLabels] : overviewLabels;
    for (const [name, longitude, latitude, minScale, kind] of geographicLabels) {
      if (scale < minScale || latitude < south || latitude > north) continue;
      const waterLabel = kind === 'river' || kind === 'lake' || kind === 'sea';
      context.font = `${waterLabel ? 'italic 600' : '600'} 11px ${font}`;
      const [x, y] = project(longitude, latitude);
      const label = [x - 4, y - 8, x + context.measureText(name).width + 10, y + 8];
      if (label[0] < 7 || label[2] > width - 8 || label[1] < 7 || label[3] > height - 7) continue;
      if (occupied.some(a => a[0] < label[2] && a[2] > label[0] && a[1] < label[3] && a[3] > label[1])) continue;
      occupied.push(label);
      context.fillStyle = waterLabel ? '#456c79' : '#56695b';
      if (!waterLabel && kind !== 'road') {
        context.beginPath();
        context.arc(x, y, 2.1, 0, Math.PI * 2);
        context.fill();
      }
      context.strokeStyle = waterLabel ? water : '#f1f4e4';
      context.lineWidth = 2.5;
      context.strokeText(name, x + 6, y);
      context.fillText(name, x + 6, y);
    }

    if (draft) {
      const [x, y] = project(draft.longitude, draft.latitude);
      context.beginPath();
      context.arc(x, y, 8, 0, Math.PI * 2);
      context.lineWidth = 3;
      context.strokeStyle = '#fff';
      context.stroke();
      context.lineWidth = 1.5;
      context.strokeStyle = '#25583f';
      context.stroke();
      context.fillStyle = '#cde425';
      context.fill();
    }

    const units = 111.195 * Math.cos(center.latitude * degrees) / (scale * cosine(center.latitude));
    const distance = [20000, 10000, 5000, 2000, 1000, 500, 200, 100, 50, 20, 10, 5, 2, 1, 0.5, 0.2, 0.1, 0.05, 0.02]
      .find(value => value / units <= 92);
    scaleLine.hidden = !distance || units < 0.001;
    if (!scaleLine.hidden) {
      scaleLine.textContent = distance < 1 ? `${Math.round(distance * 1000)} м` : `${distance} км`;
      scaleLine.style.width = `${distance / units}px`;
    }
  }

  function redraw() {
    if (hasFrame) pendingFrame ??= requestAnimationFrame(draw);
  }

  function zoom(factor, x = width / 2, y = height / 2) {
    fittedPoints = null;
    atReserve = false;
    const point = unproject(x, y);
    scale = bound(scale * factor, worldScale(), maxScale);
    const latitude = bound(point.latitude + (y - height / 2) / scale, -90, 90);
    setCenter(latitude, point.longitude - (x - width / 2) / (scale * cosine(latitude)));
    redraw();
  }

  function pan(dx, dy) {
    fittedPoints = null;
    atReserve = false;
    const {longitude, latitude} = unproject(width / 2 - dx, height / 2 - dy);
    setCenter(latitude, longitude);
    redraw();
  }

  function focus(point) {
    fittedPoints = null;
    atReserve = false;
    setCenter(point.latitude, point.longitude);
    scale = isReserve(point) ? maxScale : initialScale;
    redraw();
  }

  function focusReserve() {
    const points = markers.filter(({point, area}) => area && isReserve(point)).map(({point}) => point);
    if (!points.length) {
      focus(reserve);
      return;
    }
    const latitudes = points.map(point => point.latitude);
    focus({latitude: (Math.min(...latitudes) + Math.max(...latitudes)) / 2, longitude: longitudeFrame(points).longitude});
  }

  function fit(points) {
    fittedPoints = points;
    const box = viewport.getBoundingClientRect();
    if (!points.length || !box.width || !box.height) return;
    hasFrame = true;
    atReserve = points.every(isReserve);
    const latitudes = points.map(p => p.latitude);
    const latRange = Math.max(...latitudes) - Math.min(...latitudes);
    const {longitude, span} = longitudeFrame(points);
    setCenter(Math.min(...latitudes) + latRange / 2, longitude);
    const verticalPadding = points === russiaExtent ? 58 : 90;
    scale = bound(Math.min(initialScale, (box.height - verticalPadding) / (latRange || 1e-6),
      (box.width - 80) / ((span || 1e-6) * cosine(center.latitude))), worldScale(), maxScale);
    redraw();
  }

  const position = event => {
    const rect = viewport.getBoundingClientRect();
    return [event.clientX - rect.left - viewport.clientLeft, event.clientY - rect.top - viewport.clientTop];
  };

  function selectionBounds(gesture, point) {
    const [x, y] = point;
    return [bound(Math.min(gesture.startX, x), 0, width), bound(Math.min(gesture.startY, y), 0, height),
      bound(Math.max(gesture.startX, x), 0, width), bound(Math.max(gesture.startY, y), 0, height)];
  }

  function cancelGesture() {
    if (!pointer) return false;
    const {id, capture} = pointer;
    pointer = null;
    frame.hidden = true;
    viewport.classList.remove('is-panning');
    if (capture.hasPointerCapture(id)) capture.releasePointerCapture(id);
    return true;
  }

  function setMode(next) {
    cancelGesture();
    mode = next;
    viewport.classList.toggle('is-pan-mode', mode === 'pan');
    for (const button of modes) button.setAttribute('aria-pressed', button.dataset.mapMode === mode);
  }

  for (const button of modes) button.addEventListener('click', () => setMode(button.dataset.mapMode));
  viewport.addEventListener('pointerdown', event => {
    if (event.button !== 0 || !event.isPrimary || pointer) return;
    const capture = event.target === canvas ? canvas : event.target.closest('.station-map-marker');
    if (!capture) return;
    const [startX, startY] = position(event);
    pointer = {id: event.pointerId, capture, startX, startY, x: startX, y: startY, moved: false,
      kind: picking ? 'coordinates' : mode, additive: event.ctrlKey || event.metaKey};
    if (capture === canvas) viewport.focus({preventScroll: true});
    capture.setPointerCapture(event.pointerId);
  });
  viewport.addEventListener('pointermove', event => {
    if (pointer?.id !== event.pointerId) return;
    const [x, y] = position(event);
    const dx = x - pointer.x;
    const dy = y - pointer.y;
    if (!pointer.moved && Math.hypot(dx, dy) < 5) return;
    if (pointer.capture !== canvas) {
      // A tap remains a marker click. Capture drags on the canvas, including touch hits adjusted to a marker.
      pointer.capture = canvas;
      canvas.setPointerCapture(event.pointerId);
      viewport.focus({preventScroll: true});
    }
    pointer.moved = true;
    pointer.x = x;
    pointer.y = y;
    if (pointer.kind === 'select') {
      const [left, top, right, bottom] = selectionBounds(pointer, [x, y]);
      frame.style.left = `${left}px`;
      frame.style.top = `${top}px`;
      frame.style.width = `${right - left}px`;
      frame.style.height = `${bottom - top}px`;
      frame.hidden = false;
    } else {
      viewport.classList.add('is-panning');
      pan(dx, dy);
    }
  });
  viewport.addEventListener('pointerup', event => {
    if (pointer?.id !== event.pointerId) return;
    const gesture = pointer;
    cancelGesture();
    if (gesture.kind === 'coordinates' && !gesture.moved) onPick(unproject(...position(event)));
    if (gesture.kind !== 'select' || !gesture.moved) return;
    const [left, top, right, bottom] = selectionBounds(gesture, position(event));
    const included = new Set(displayedMarkers.filter(({x, y}) => x >= left && x <= right && y >= top && y <= bottom)
      .map(({marker}) => marker));
    onSelect(markers.filter(marker => included.has(marker)).map(marker => marker.station),
      gesture.additive || event.ctrlKey || event.metaKey);
  });
  for (const type of ['pointercancel', 'lostpointercapture']) {
    viewport.addEventListener(type, event => {
      if (pointer?.id === event.pointerId && (type === 'pointercancel' || pointer.capture === event.target)) cancelGesture();
    });
  }
  canvas.addEventListener('wheel', event => {
    event.preventDefault();
    if (!pointer) zoom(event.deltaY < 0 ? 1.25 : 0.8, ...position(event));
  }, {passive: false});
  canvas.addEventListener('contextmenu', event => {
    if (event.ctrlKey && pointer?.kind === 'select') event.preventDefault();
  });
  viewport.addEventListener('keydown', event => {
    if (event.target !== viewport) return;
    const movement = {ArrowLeft: [44, 0], ArrowRight: [-44, 0], ArrowUp: [0, 44], ArrowDown: [0, -44]};
    if (event.key === 'Escape' && cancelGesture()) event.stopPropagation();
    else if (movement[event.key]) pan(...movement[event.key]);
    else if (['+', '='].includes(event.key)) zoom(1.5);
    else if (event.key === '-') zoom(1 / 1.5);
    else if (picking && event.key === 'Enter') onPick(center);
    else return;
    event.preventDefault();
  });

  viewport.querySelector('[data-fit-russia]').addEventListener('click', () => fit(russiaExtent));
  viewport.querySelector('[data-focus-reserve]').addEventListener('click', focusReserve);
  const observer = new ResizeObserver(() => fittedPoints ? fit(fittedPoints) : redraw());
  observer.observe(viewport);
  return {
    zoom, focus, fit, cancelGesture,
    setMarkers(next) {
      markers = next;
      displayedMarkers = [];
      for (const marker of markers) marker.element.disabled = picking;
      overlay.replaceChildren(...markers.map(marker => marker.element));
      redraw();
    },
    setDraft(point) {
      draft = point;
      redraw();
    },
    pickCoordinates(active) {
      cancelGesture();
      picking = active;
      for (const button of modes) button.disabled = active;
      for (const marker of markers) marker.element.disabled = active;
      viewport.classList.toggle('is-picking', active);
      if (active) viewport.focus();
    },
    destroy() {
      cancelGesture();
      observer.disconnect();
      cancelAnimationFrame(pendingFrame);
    },
  };
}

function mapContents() {
  const hintId = `station-map-shortcut-${++mapId}`;
  return `<section class="station-map-column" aria-label="Географическая карта">
  <div class="station-map-viewport" tabindex="0" role="group" aria-label="Карта станций. Стрелки перемещают карту, клавиши плюс и минус меняют масштаб" aria-describedby="${hintId}">
    <canvas aria-hidden="true"></canvas>
    <div class="station-map-frame" aria-hidden="true" hidden></div>
    <div class="station-map-markers"></div>
    <div class="station-map-modes" role="group" aria-label="Режим карты">
      <button class="btn line" type="button" data-map-mode="select" aria-label="Выделение рамкой" aria-pressed="true">${icon('select')} <span>Выделение рамкой</span></button>
      <button class="btn line" type="button" data-map-mode="pan" aria-label="Перемещение" aria-pressed="false">${icon('pan')} <span>Перемещение</span></button>
    </div>
    <div class="station-map-tools" aria-label="Управление картой">
      <button class="icon-btn" type="button" data-zoom-in title="Приблизить" aria-label="Приблизить">${icon('plus')}</button>
      <button class="icon-btn" type="button" data-zoom-out title="Отдалить" aria-label="Отдалить">${icon('minus')}</button>
    </div>
    <div class="station-map-jumps" role="group" aria-label="Область карты">
      <button class="btn line" type="button" data-fit-russia>Вся Россия</button>
      <button class="btn line" type="button" data-focus-reserve aria-label="Детальный вид Красного">Красное</button>
      <button class="btn line" type="button" data-fit disabled>К станциям</button>
    </div>
    <div class="station-map-scale" aria-hidden="true"></div>
    <p class="station-map-instruction" hidden>Укажите точку на карте или нажмите Enter для точки в центре.</p>
  </div>
  <div class="station-map-source">
    <span>Рельеф и география · <a href="https://www.naturalearthdata.com/about/terms-of-use/" target="_blank" rel="noreferrer">Natural Earth</a>, <a href="https://www.geonames.org/export/" target="_blank" rel="noreferrer">GeoNames</a></span>
    <span data-reserve-credit hidden><a href="https://esa-worldcover.org/en/data-access" target="_blank" rel="noreferrer">© ESA WorldCover project 2021</a> / Contains modified Copernicus Sentinel data (2021) processed by ESA WorldCover consortium (<a href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noreferrer">CC BY 4.0</a>)</span>
    <span data-reserve-objects-credit hidden>Местные объекты · <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">© OpenStreetMap contributors</a> (<a href="https://opendatacommons.org/licenses/odbl/1-0/" target="_blank" rel="noreferrer">ODbL 1.0</a>)</span>
    <span data-area-note hidden>Пунктир обозначает приблизительное местоположение.</span>
  </div>
  <ul class="station-terrain-legend" data-terrain-legend aria-label="Тип местности на карте" hidden></ul>
  <p id="${hintId}" class="station-map-shortcut"><span data-displaced-note hidden>Линии ведут от кнопок станций к их точкам на карте. </span><span data-dense-note hidden>Приблизьте карту, чтобы показать остальные метки. </span><span class="station-map-mouse-tip">Обведите кнопки станций рамкой. Ctrl или ⌘ добавят станции к выбору.</span><span class="station-map-touch-tip">В режиме выделения обведите кнопки станций пальцем.</span></p>
</section>`;
}

function stationListContents(action = '') {
  return `<section data-picker-list aria-label="Список метеостанций">
    <div class="station-picker-list-head"><h3>Выбранные станции</h3>${action}</div>
    <p class="station-list-tip" id="station-stats-tip-${mapId}" data-selection-tip>Флажок включает станцию в статистику.</p>
    <div class="station-picker-list" data-list>
      <p class="station-list-empty" data-empty-selection></p>
      <div class="station-list-group" data-selected-stations role="group" aria-label="Выбранные станции"></div>
      <h4 class="station-list-other-title" data-other-title>Остальные станции</h4>
      <div class="station-list-group" data-other-stations role="group" aria-label="Остальные станции"></div>
    </div>
  </section>`;
}

function createStationSelection(root, {onPick, onChange, emptyText}) {
  const get = selector => root.querySelector(selector);
  const viewport = get('.station-map-viewport');
  const fitButton = get('[data-fit]');
  const selectedList = get('[data-selected-stations]');
  const otherList = get('[data-other-stations]');
  const emptySelection = get('[data-empty-selection]');
  const otherTitle = get('[data-other-title]');
  const selectionTip = get('[data-selection-tip]');
  let stations = [];
  let selected = new Set();
  let items = [];
  let markers = [];
  let catalogKey;
  let initialPosition = 'pending';
  const map = createMap(viewport, onPick, (included, additive) => {
    const next = new Set(additive ? selected : []);
    for (const station of included) next.add(station.id);
    if (next.size === selected.size && [...next].every(id => selected.has(id))) return;
    selected = next;
    refreshSelection();
    onChange([...selected]);
  });

  function toggleStation(id) {
    if (selected.has(id)) selected.delete(id);
    else selected.add(id);
    refreshSelection();
    onChange([...selected]);
  }

  function fitMarkers() {
    map.fit(markers.map(marker => marker.point));
  }

  get('[data-zoom-in]').addEventListener('click', () => map.zoom(1.5));
  get('[data-zoom-out]').addEventListener('click', () => map.zoom(1 / 1.5));
  fitButton.addEventListener('click', fitMarkers);

  function refreshSelection() {
    const active = document.activeElement;
    const selectedRows = [];
    const otherRows = [];
    for (const {station, input, row} of items) {
      input.checked = selected.has(station.id);
      input.title = input.checked ? 'Скрыть из статистики' : 'Включить в статистику';
      (input.checked ? selectedRows : otherRows).push(row);
    }
    if (selectedList.childElementCount !== selectedRows.length || selectedRows.some((row, i) => selectedList.children[i] !== row)) {
      selectedList.replaceChildren(...selectedRows);
    }
    if (otherList.childElementCount !== otherRows.length || otherRows.some((row, i) => otherList.children[i] !== row)) {
      otherList.replaceChildren(...otherRows);
    }
    selectedList.hidden = !selectedRows.length;
    otherList.hidden = !otherRows.length;
    otherTitle.hidden = !otherRows.length;
    otherTitle.textContent = selectedRows.length ? 'Остальные станции' : 'Все станции';
    emptySelection.hidden = !!selectedRows.length;
    emptySelection.textContent = items.length ? 'Выберите станции на карте или в списке.' : emptyText;
    selectionTip.hidden = !items.length;
    if (root.contains(active) && document.activeElement !== active) {
      active.focus({preventScroll: true});
      active.scrollIntoView({block: 'nearest'});
    }
    for (const {element, station} of markers) {
      element.setAttribute('aria-pressed', String(selected.has(station.id)));
    }
  }

  function rebuild() {
    items = stations.map(station => {
      const point = location(station);
      const row = document.createElement('div');
      row.className = 'station-picker-row';
      row.innerHTML = `<label><input type="checkbox"><span class="station-row-dot" aria-hidden="true"></span><span><strong></strong><small></small></span></label>`;
      row.querySelector('strong').textContent = station.label;
      row.querySelector('.station-row-dot').style.backgroundColor = station.color || '#2b7650';
      const locationLabel = stationLocation(station, point);
      row.querySelector('small').textContent = `${terrains[terrainType(station)][0]} · ${locationLabel}`;
      const input = row.querySelector('input');
      input.setAttribute('aria-describedby', selectionTip.id);
      input.addEventListener('change', () => {
        if (input.checked) selected.add(station.id);
        else selected.delete(station.id);
        refreshSelection();
        onChange([...selected]);
      });
      const actions = document.createElement('div');
      actions.className = 'station-row-actions';
      const id = `station-passport-${++passportId}`;
      const showPassport = document.createElement('button');
      showPassport.className = 'icon-btn';
      showPassport.type = 'button';
      showPassport.title = 'Паспорт станции';
      showPassport.setAttribute('aria-label', `Паспорт станции ${station.label}`);
      showPassport.setAttribute('aria-expanded', 'false');
      showPassport.setAttribute('aria-controls', id);
      showPassport.innerHTML = icon('passport');
      const passport = stationPassport(station, locationLabel, id);
      showPassport.addEventListener('click', () => {
        passport.hidden = !passport.hidden;
        showPassport.setAttribute('aria-expanded', !passport.hidden);
        if (!passport.hidden) showPassport.scrollIntoView({block: 'nearest'});
      });
      actions.append(showPassport);
      if (point) {
        const locate = document.createElement('button');
        locate.className = 'icon-btn station-row-locate';
        locate.type = 'button';
        locate.title = 'Показать на карте';
        locate.setAttribute('aria-label', `Показать на карте: ${station.label}`);
        locate.innerHTML = icon('locate');
        locate.addEventListener('click', () => {
          map.focus(point);
          viewport.focus();
        });
        actions.append(locate);
      }
      row.append(actions, passport);
      return {station, row, input};
    });

    const seenTypes = new Set();
    markers = stations.flatMap(station => {
      const point = location(station);
      if (!point) return [];
      const area = station.location_precision === 'area';
      const type = terrainType(station);
      const color = terrains[type][1];
      seenTypes.add(type);
      const element = document.createElement('button');
      element.type = 'button';
      element.hidden = true;
      element.className = `station-map-marker${area ? ' station-map-marker-area' : ''}`;
      element.dataset.stationId = station.id;
      element.title = area ? `${station.label} · приблизительно` : station.label;
      element.setAttribute('aria-label', station.label);
      element.style.setProperty('--terrain-fill', color);
      const caption = document.createElement('span');
      caption.textContent = station.label.split(' · ')[0];
      element.append(caption);
      element.addEventListener('click', () => toggleStation(station.id));
      return [{station, point, area, color, element}];
    });
    const legend = get('[data-terrain-legend]');
    legend.replaceChildren(...Object.entries(terrains).filter(([type]) => seenTypes.has(type)).map(([, [label, color]]) => {
      const item = document.createElement('li');
      const dot = document.createElement('span');
      dot.setAttribute('aria-hidden', 'true');
      dot.style.backgroundColor = color;
      item.append(dot, document.createTextNode(label));
      return item;
    }));
    legend.hidden = !seenTypes.size;
    fitButton.disabled = !markers.length;
    map.setMarkers(markers);
    if (markers.length && initialPosition !== 'stations') {
      initialPosition = 'stations';
      if (markers.some(({station}) => station.archive)) map.fit([reserve]);
      else fitMarkers();
    } else if (initialPosition === 'pending') {
      initialPosition = 'country';
      map.fit(russiaExtent);
    }
  }

  return {
    map,
    ids: () => [...selected],
    focusCheckbox(id) {
      items.find(item => item.station.id === id)?.input.focus();
    },
    update(catalog, ids) {
      stations = catalog;
      const stationIds = new Set(stations.map(station => station.id));
      selected = new Set(ids.filter(id => stationIds.has(id)));
      const nextKey = JSON.stringify(stations.map(({id, label, archive, color, terrain, latitude, longitude,
        location_precision, location_label, location_reference, params}) =>
        [id, label, archive, color, terrain, latitude, longitude, location_precision, location_label, location_reference, params]));
      if (nextKey !== catalogKey) {
        catalogKey = nextKey;
        rebuild();
      }
      refreshSelection();
    },
  };
}

export function mountStationOverview(container, {onChange = () => {}, onExpand = () => {}} = {}) {
  container.classList.add('station-overview');
  container.innerHTML = `<div class="station-overview-heading">
    <h2>Карта метеостанций</h2>
    <button class="btn line" type="button" data-expand-map aria-haspopup="dialog">${icon('fit')} Открыть карту</button>
  </div>
  <div class="station-overview-body">
    ${mapContents()}
    ${stationListContents()}
  </div>`;
  const selection = createStationSelection(container, {onChange, emptyText: 'Станции не найдены.'});
  container.querySelector('[data-expand-map]').addEventListener('click', onExpand);
  return {
    update: selection.update,
    destroy() {
      selection.map.destroy();
      container.replaceChildren();
      container.classList.remove('station-overview');
    },
  };
}

function dialogContents(canRegister) {
  const registerButton = canRegister ? `<button class="btn line" type="button" data-add>${icon('plus')} Добавить</button>` : '';
  return `
    <div class="station-picker-heading">
      <div>
        <h2 id="station-picker-title">Метеостанции</h2>
        <p id="station-picker-description">Выберите станции в списке или выделите их рамкой на карте.</p>
      </div>
      <button class="icon-btn" type="button" data-close aria-label="Закрыть" autofocus>${icon('close')}</button>
    </div>
    <div class="station-picker-body">
      ${mapContents()}
      <div class="station-picker-side">
        ${stationListContents(registerButton)}
        <form data-station-form hidden>
          <div class="station-picker-list-head"><h3>Паспорт станции</h3><button class="btn line" type="button" data-back>К списку</button></div>
          <fieldset>
            <label class="field"><span>Название станции</span><input name="label" type="text" required maxlength="100" placeholder="Например, Лесной кордон"></label>
            <label class="field"><span>Тип местности</span><select name="terrain">
              <option value="unknown">Не указан</option>
              ${Object.entries(terrains).filter(([type]) => type !== 'unknown').map(([type, [label]]) => `<option value="${type}">${label}</option>`).join('')}
            </select></label>
            <div class="station-form-coordinates">
              <label class="field"><span>Широта</span><input name="latitude" type="number" inputmode="decimal" min="-90" max="90" step="any" placeholder="±90" required></label>
              <label class="field"><span>Долгота</span><input name="longitude" type="number" inputmode="decimal" min="-180" max="180" step="any" placeholder="±180" required></label>
            </div>
            <button class="btn line" type="button" data-pick aria-pressed="false">${icon('pin')} Указать на карте</button>
            <div class="station-form-params"><div>Измеряемые показатели</div><div data-params role="group" aria-label="Измеряемые показатели"></div></div>
            <details>
              <summary>Дополнительные поля</summary>
              <label class="field"><span>Код станции</span><input name="id" type="text" maxlength="56" pattern="[a-z][a-z0-9_\\-]*" placeholder="Сформируется автоматически" title="Строчные латинские буквы, цифры, дефис и подчёркивание"></label>
              <label class="field"><span>Как считать покрытие суток</span><select name="slot_minutes"><option value="">По числу разных часов</option><option value="1">По числу разных минут</option></select></label>
              <label class="field"><span>Минимум сроков за сутки</span><input name="minimum_slots" type="number" min="1" max="1440" step="1" placeholder="По умолчанию · 18"></label>
            </details>
            <p class="station-form-error" role="alert" hidden></p>
            <button class="btn primary" type="submit" data-save>Зарегистрировать станцию</button>
          </fieldset>
        </form>
      </div>
    </div>
    <div class="station-picker-footer">
      <span data-selection-count aria-live="polite"></span>
      <div><button class="btn line" type="button" data-close>Отмена</button><button class="btn primary" type="button" data-apply>Применить</button></div>
    </div>`;
}

export async function pickStations(stations, selectedIds = [], {canRegister = false} = {}) {
  const before = document.activeElement;
  const dialog = document.createElement('dialog');
  dialog.className = 'station-picker';
  dialog.setAttribute('aria-labelledby', 'station-picker-title');
  dialog.setAttribute('aria-describedby', 'station-picker-description');
  dialog.innerHTML = dialogContents(canRegister);
  document.body.append(dialog);
  const get = selector => dialog.querySelector(selector);
  const form = get('[data-station-form]');
  const fields = form.elements;
  const apply = get('[data-apply]');
  const add = get('[data-add]');
  const pick = get('[data-pick]');
  const error = get('.station-form-error');
  const instruction = get('.station-map-instruction');
  const paramsGroup = get('[data-params]');
  let parameterOptions = [...new Map(stations.flatMap(station => station.params || []).map(item => [item.id, item])).values()];
  let parameterRequest;
  let editing = false;
  let picking = false;
  let saving = false;
  let result = null;
  const selection = createStationSelection(dialog, {
    emptyText: 'Добавьте первую станцию.',
    onChange: refreshFooter,
    onPick(point) {
      fields.latitude.value = point.latitude.toFixed(5);
      fields.longitude.value = point.longitude.toFixed(5);
      setPicking(false);
      previewCoordinates();
      pick.focus();
    },
  });
  const {map} = selection;

  function refreshFooter(ids = selection.ids()) {
    get('[data-selection-count]').textContent = `Выбрано ${ids.length} из ${stations.length}`;
    apply.disabled = !ids.length || editing;
  }

  function setPicking(active) {
    picking = active;
    instruction.hidden = !active;
    pick.setAttribute('aria-pressed', active);
    map.pickCoordinates(active);
  }

  function formPoint() {
    const latitude = fields.latitude.valueAsNumber;
    const longitude = fields.longitude.valueAsNumber;
    return location({latitude, longitude});
  }

  function previewCoordinates() {
    map.setDraft(formPoint());
  }

  function renderParameters() {
    const checked = new Set([...paramsGroup.querySelectorAll('input:checked')].map(input => input.value));
    const existing = [...paramsGroup.querySelectorAll('input')];
    if (existing.length === parameterOptions.length && existing.every((input, index) => input.value === parameterOptions[index].id)) return;
    paramsGroup.replaceChildren(...parameterOptions.map(({id, label, unit}) => {
      const option = document.createElement('label');
      const input = document.createElement('input');
      input.type = 'checkbox';
      input.name = 'params';
      input.value = id;
      input.checked = checked.has(id);
      option.append(input, document.createTextNode(unit ? `${label} · ${unit}` : label));
      return option;
    }));
  }

  function loadParameters() {
    if (parameterRequest) return;
    parameterRequest = fetch('/api/stations').then(response => {
      if (!response.ok) throw new Error('Каталог недоступен.');
      return response.json();
    }).then(body => {
      if (Array.isArray(body.param_options) && body.param_options.length && dialog.isConnected) {
        parameterOptions = body.param_options;
        renderParameters();
      }
    }).catch(() => {
      parameterRequest = undefined;
      if (!parameterOptions.length && editing && dialog.isConnected) {
        error.textContent = 'Не удалось загрузить показатели. Вернитесь к списку и повторите попытку.';
        error.hidden = false;
      }
    });
  }

  function showForm(active) {
    editing = active;
    form.hidden = !active;
    get('[data-picker-list]').hidden = active;
    setPicking(false);
    if (active) {
      form.reset();
      form.querySelector('details').open = false;
      renderParameters();
      loadParameters();
      error.hidden = true;
      fields.label.focus();
    } else {
      add?.focus();
    }
    map.setDraft(null);
    refreshFooter();
  }

  add?.addEventListener('click', () => showForm(true));
  get('[data-back]').addEventListener('click', () => showForm(false));
  pick.addEventListener('click', () => setPicking(!picking));
  fields.latitude.addEventListener('input', previewCoordinates);
  fields.longitude.addEventListener('input', previewCoordinates);
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (!canRegister || saving) return;
    error.hidden = true;
    const point = formPoint();
    if (!point) return;
    const data = new FormData(form);
    const params = data.getAll('params');
    if (!data.get('label').trim() || !params.length) {
      error.textContent = params.length ? 'Введите название станции.' : 'Укажите хотя бы один показатель.';
      error.hidden = false;
      if (params.length) fields.label.focus();
      else paramsGroup.querySelector('input')?.focus();
      return;
    }
    const passport = {label: data.get('label').trim(), terrain: data.get('terrain'), params, ...point};
    if (data.get('id')) passport.id = data.get('id');
    for (const key of ['minimum_slots', 'slot_minutes']) {
      if (data.get(key)) passport[key] = Number(data.get(key));
    }
    saving = true;
    setPicking(false);
    form.querySelector('fieldset').disabled = true;
    get('[data-back]').disabled = true;
    for (const button of dialog.querySelectorAll('[data-close]')) button.disabled = true;
    const save = get('[data-save]');
    save.textContent = 'Регистрация…';
    try {
      const response = await fetch('/api/stations', {
        method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(passport),
      });
      const body = await response.json();
      if (!response.ok || !body.station?.id) throw new Error(body.error || body.message || 'Станцию не удалось зарегистрировать.');
      stations.push(body.station);
      selection.update(stations, [...selection.ids(), body.station.id]);
      showForm(false);
      selection.focusCheckbox(body.station.id);
      const point = location(body.station);
      if (point) map.focus(point);
    } catch (failure) {
      error.textContent = failure instanceof TypeError || failure instanceof SyntaxError
        ? 'Каталог недоступен. Проверьте связь с сервером и повторите попытку.' : failure.message;
      error.hidden = false;
    } finally {
      saving = false;
      form.querySelector('fieldset').disabled = false;
      get('[data-back]').disabled = false;
      for (const button of dialog.querySelectorAll('[data-close]')) button.disabled = false;
      save.textContent = 'Зарегистрировать станцию';
    }
  });

  for (const button of dialog.querySelectorAll('[data-close]')) button.addEventListener('click', () => dialog.close());
  dialog.addEventListener('cancel', event => {
    if (map.cancelGesture() || saving) event.preventDefault();
  });
  apply.addEventListener('click', () => {
    result = selection.ids();
    dialog.close();
  });

  const finished = new Promise(resolve => dialog.addEventListener('close', () => {
    map.destroy();
    dialog.remove();
    before?.focus();
    resolve(result);
  }, {once: true}));
  dialog.showModal();
  selection.update(stations, selectedIds);
  refreshFooter();
  return finished;
}
